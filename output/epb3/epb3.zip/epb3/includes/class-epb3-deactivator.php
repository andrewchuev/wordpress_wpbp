<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://andrew.com
 * @since      1.0.0
 *
 * @package    Epb3
 * @subpackage Epb3/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Epb3
 * @subpackage Epb3/includes
 * @author     Andrew <andrew@gmail.com>
 */
class Epb3_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
