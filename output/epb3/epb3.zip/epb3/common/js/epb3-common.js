(function( $ ) {
	'use strict';

	console.log('Hello from common');

})( jQuery );
